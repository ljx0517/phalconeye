771DAFAB-FCC7-4B42-82C2-96F65F9DDF06		Common Guid shared by sample with multiple languages.
7A2E6697-1785-45E7-8C6C-57EE23A86120		Unique Guid for each sample regardless of language.
