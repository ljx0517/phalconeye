6E9A7F17-1E6B-4772-9A9C-AF3A37FC0218		Common Guid shared by sample with multiple languages.
39977F4C-2EAA-45CE-A199-3AEB41A9C558		Unique Guid for each sample regardless of language.
