"use strict";

// define app (depends on "wijmo", and also on the modules that contain our directives)
// IMPORTANT: if you forget to include a directive, there will be no error message!!!
angular.module("gdash", [ "esri" ]);