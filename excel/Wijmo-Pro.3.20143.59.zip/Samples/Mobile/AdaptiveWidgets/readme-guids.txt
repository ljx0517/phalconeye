AA3C75AB-7729-4A39-BD3C-9DA3532F93DB		Common Guid shared by sample with multiple languages.
94A568CD-EF91-464F-9433-8A2CF2192A75		Unique Guid for each sample regardless of language.
