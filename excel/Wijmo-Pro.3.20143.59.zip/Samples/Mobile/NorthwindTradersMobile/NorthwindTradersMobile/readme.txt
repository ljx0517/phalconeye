Northwind Traders Mobile
--------------------------------------------------------------------------------------------
Mobile Application made with Wijmo AppView, AjaxDataView and a Northwind REST service 

This application uses AppView for layout, structure and navigation. The app.html file is a 
shell that includes AppView. All of the AppViewPages are in the Partials folder. AppView loads 
them asynchronously. 

Inside the partial views you will see JavaScript for handling data and binding. The Views are 
bound using Knockout. This sample demonstrates the power of AppView and how easy it makes 
mobile development.

<product>Wijmo;HTML5</product>