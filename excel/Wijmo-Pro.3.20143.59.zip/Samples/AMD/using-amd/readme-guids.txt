635EED87-0FE0-4D6F-926C-619B7595A263		Common Guid shared by sample with multiple languages.
DF9414B4-ABE4-4DDB-AECE-D6CA79A7449F		Unique Guid for each sample regardless of language.
